extern void popup_an_error(const char *fmt, ...);
extern void popup_an_errno(int err, const char *fmt, ...);
